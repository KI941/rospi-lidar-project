date
ping ubuntu.com
sudo apt install htpdate
date
sudo update
sudo apt update
sudo apt upgrade
sudo reboot
sudo apt install ubuntu-desktop
systemctl status gdm3
echo $XDG_CURRENT_DESKTOP
systemctl status gdm3
systemctl get-default
sudo systemctl set-default graphical.target
sudo systemctl start gdm3
sudo reboot
systemctl get-default
systemctl status gdm3
sudo nano /etc/gdm3/custom.conf
wget https://archive.realvnc.com/install/repo_setup.sh
sudo apt update
sudo apt install realvnc-vnc-server realvnc-vnc-viewer -y
echo $XDG_SESSION_TYPE
systemctl get-default
sudo systemctl set-default graphical.target
sudo systemctl enable gdm3
sudo systemctl start gdm3
sudo systemctl enable gdm3
echo $XDG_SESSION_TYPE
sudo nano /boot/firmware/config.txt
systemctl get-default
# graphical.target
systemctl status gdm3
# Active: active (running)
echo $XDG_SESSION_TYPE
# x11
echo $XDG_SESSION_TYPE
systemctl get-default
sudo systemctl isolate graphical.target
echo $XDG_SESSION_TYPE
systemctl status gdm3
sudo systemctl set-default multi-user.target
sudo reboot
sudo apt update
sudo apt install tigervnc-standalone-server tigervnc-common xfce4 xfce4-goodies -y
vncpasswd
nano ~/.vnc/xstartup
chmod +x ~/.vnc/xstartup
vncserver -localhost no :1
wget https://download.nomachine.com/download/8.13/Linux/nomachine_8.13.1_1_arm64.deb
sudo dpkg -i nomachine_*.deb
sudo systemctl enable nxserver
sudo systemctl start nxserver
wget https://download.nomachine.com/download/8.13/Linux/nomachine_8.13.1_1_arm64.deb
sudo dpkg -i nomachine_*.deb
sudo systemctl enable nxserver
sudo systemctl start nxserver
cd 
ls
sudo dpkg -i nomachine_*.deb
echo $XDG_SESSION_TYPE
wget https://download.nomachine.com/download/8.13/Linux/nomachine_8.13.1_1_arm64.deb
sudo dpkg -i nomachine_*.deb
sudo systemctl enable nxserver
sudo systemctl start nxserver
rm -f nomachine_*.deb*
ls
wget https://download.nomachine.com/download/8.13/Linux/nomachine_8.13.1_1_arm64.deb
ls -lh nomachine_8.13.1_1_arm64.deb
sudo dpkg -i nomachine_8.13.1_1_arm64.deb
sudo apt -f install -y
rm -f nomachine_*.deb*
sudo apt update
sudo apt install -y curl
curl -L -o nomachine.deb https://download.nomachine.com/download/8.13/Linux/nomachine_8.13.1_1_arm64.deb
ls -lh nomachine.deb
ls -lh nomachine.debls -lh nomachine.deb
file nomachine.deb
wget -qO- https://keys.nomachine.com/GPG-KEY-NX | sudo gpg --dearmor -o /usr/share/keyrings/nomachine.gpg
sudo apt update
sudo apt install nomachine -y
sudo systemctl enable nxserver
sudo systemctl start nxserver
sudo dpkg -i nomachine_8.13.1_1_arm64.deb
sudo apt -f install -y
sudo apt update
sudo apt install tigervnc-standalone-server xfce4 xfce4-goodies -y
vncpasswd
mkdir -p ~/.vnc
nano ~/.vnc/xstartup
chmod +x ~/.vnc/xstartup
vncserver -localhost no :1
sudo poweroff
clear
sudo apt update && sudo apt upgrade -y\
ls
cd Documents
ls
cd
cls
clear
ls
cd Desk
cd Desktop/
ls
clear
locale  # check for UTF-8
sudo apt update && sudo apt install locales
sudo locale-gen en_US en_US.UTF-8
sudo update-locale LC_ALL=en_US.UTF-8 LANG=en_US.UTF-8
export LANG=en_US.UTF-8
locale  # verify settings
sudo apt install software-properties-common
sudo add-apt-repository universe
cd 
sudo apt update && sudo apt install curl -y
export ROS_APT_SOURCE_VERSION=$(curl -s https://api.github.com/repos/ros-infrastructure/ros-apt-source/releases/latest | grep -F "tag_name" | awk -F\" '{print $4}')
curl -L -o /tmp/ros2-apt-source.deb "https://github.com/ros-infrastructure/ros-apt-source/releases/download/${ROS_APT_SOURCE_VERSION}/ros2-apt-source_${ROS_APT_SOURCE_VERSION}.$(. /etc/os-release && echo ${UBUNTU_CODENAME:-${VERSION_CODENAME}})_all.deb"
sudo dpkg -i /tmp/ros2-apt-source.deb
sudo apt update
sudo apt upgrade
sudo apt install ros-humble-ros-base
clear
cd de
ls
cd Desktop/
ls
cd
sudo apt update
sudo apt install ros-humble-desktop
quit
ros2 launch ydlidar_ros2_driver ydlidar_launch.py
ls
echo "export ROS_DOMAIN_ID=10" >> ~/.bashrc
echo "export ROS_LOCALHOST_ONLY=0" >> ~/.bashrc
source ~/.bashrc
gedit ~/.bashrc
nano ~/.bashrc
ping 192.168.0.193
tmux
sudo apt install ubuntu-desktop-minimal terminator -y
sudo reboot
Ctrl + b  then  "

source ~/.bashrc
ls
ros2 launch rplidar_ros rplidar_a1_launch.py 
cd
ros2 topic list
ros2 topic echo /scan
ros2 topic list
cd
nano ~/.bashrc
ping 192.168.223.128
terminator
ls
ls /dev/ttyUSB*
cd ~
mkdir -p ros2_ws/src
cd ros2_ws/src
git clone https://github.com/Slamtec/rplidar_ros.git -b ros2
cd ~/ros2_ws
source /opt/ros/humble/setup.bash
colcon build
source install/setup.bash
cd
sudo apt install ros-dev-tools
cd ~/ros2_ws
source /opt/ros/humble/setup.bash
colcon build
source install/setup.bash
echo "source ~/ros2_ws/install/setup.bash" >> ~/.bashrc
ros2 launch rplidar_ros rplidar_a1_launch.py 
tmux
ping 192.168.223.128
ros2 launch rplidar_ros rplidar_a1_launch.py 
ros2 topic list
ros2 launch slam_toolbox online_async_launch.py slam_params_file:=/opt/ros/humble/share/slam_toolbox/config/mapper_params_online_async.yaml
source ~/.bashrc 
ros2 launch slam_toolbox online_async_launch.py
clear
ros2 node list
ros2 topic list
ros2 topic hz /map
clear
source ~/.bashrc
ros2 launch rplidar_ros rplidar_a1_launch.py 
clear
sudo apt update
sudo apt install -y ros-humble-cartographer ros-humble-cartographer-ros
ros2 pkg list | grep cartographer
mkdir -p ~/cartographer_ws/config
cd ~/cartographer_ws/config
nano handheld_2d.lua
cd
ros2 launch rplidar_ros rplidar_a1_launch.py 
soucre ~/.bashrc
source ~/.bashrc
ros2 launch slam_toolbox online_async_launch.py slam_params_file:=/opt/ros/humble/share/slam_toolbox/config/mapper_params_online_async.yaml
ros2 topic echo /scan
clear
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 map laser
nano ~/handheld_slam.yaml
ros2 launch slam_toolbox online_async_launch.py slam_params_file:=/home/$USER/handheld_slam.yaml
ros2 topic list
nano ~/handheld_slam.yaml
ros2 launch slam_toolbox online_async_launch.py slam_params_file:=/home/$USER/handheld_slam.yaml
clear
ros2 run cartographer_ros cartographer_node   -configuration_directory ~/cartographer_ws/config   -configuration_basename handheld_2d.lua
ros2 run cartographer_ros occupancy_grid_node
ros2 run cartographer_ros cartographer_node   -configuration_directory ~/cartographer_ws/config   -configuration_basename handheld_2d.lua
[200~cd /opt/ros/humble/share/cartographer/configuration_files
~
cd /opt/ros/humble/share/cartographer/configuration_files
ls
sudo nano handheld_2d.lua
cd
ros2 run cartographer_ros cartographer_node   -configuration_directory /opt/ros/humble/share/cartographer/configuration_files   -configuration_basename handheld_2d.lua
ls /opt/ros/humble/share/cartographer/configuration_files
sudo apt remove --purge -y ros-humble-cartographer ros-humble-cartographer-ros
sudo apt autoremove -y
sudo apt update
sudo apt install -y ros-humble-cartographer ros-humble-cartographer-ros ros-humble-cartographer-ros-msgs
ls /opt/ros/humble/share/cartographer/configuration_files
ros2 run cartographer_ros cartographer_node   -configuration_directory /opt/ros/humble/share/cartographer/configuration_files   -configuration_basename backpack_2d.lua
cd
mkdir -p ~/cartographer_config
cd ~/cartographer_config
nano map_builder.lua
nano trajectory_builder.lua
nano handheld_2d.lua
ros2 run cartographer_ros cartographer_node   -configuration_directory ~/cartographer_config   -configuration_basename handheld_2d.lua
cd
ls
cd ros2_ws/
cd src/
ls
git clone https://github.com/ros-perception/slam_gmapping.git -b ros2
git clone https://github.com/ros-perception/openslam_gmapping.git
cd ..
ls
rosdep update
rosdep install --from-paths src --ignore-src -r -y
sudo rosdep update
cd ros2_ws/sudo rosdep init
sudo rosdep init
rosdep update
rosdep --version
cd src/
git clone https://github.com/ros-perception/openslam_gmapping.git
ls
cd openslam_gmapping/
ls
cd ..
git clone https://github.com/ros-perception/slam_gmapping.git
cd ..
rosdep install --from-paths src --ignore-src -r -y
source /opt/ros/humble/setup.bash
colcon build
colcon build --symlink-install
cd src/
ls
rm -f openslam_gmapping/
rmdir openslam_gmapping/
ls
cd openslam_gmapping/
ls
cd ..
ls
cd slam_gmapping/
ls
cd slam_gmapping/
ls
cd ..
l
scd gmapping/
l
cd gmapping/
l
ls
cd ..
ls
rm openslam_gmapping
rmdir openslam_gmapping
rm -r openslam_gmapping/
rm -r openslam_gmapping
ls
cd openslam_gmapping/
;s
ls
cd ..
rmdir openslam_gmapping
rm -rf openslam_gmapping/
ls
rm -rf slam_gmapping/
ls
cd ..
colcon build --symlink-innstall
colcon build --symlink-install
cd ..
ls
cd ros2_ws/
ls
cd src/
ls
cd ..
cd
sudo apt update
sudo apt install -y build-essential cmake git python3-rosdep python3-colcon-common-extensions python3-vcstool
sudo rosdep init
rosdep update
mkdir -p ~/gmapping_ws/src
cd ~/gmapping_ws/src
git clone https://github.com/ros-perception/slam_gmapping.git
cd ~/gmapping_ws
rosdep install --from-paths src --ignore-src -r -y
source /opt/ros/humble/setup.bash
colcon build
Starting >>> gmapping
--- stderr: gmapping                         
CMake Deprecation Warning at CMakeLists.txt:1 (cmake_minimum_required):
CMake Error at CMakeLists.txt:4 (find_package):
---
Failed   <<< gmapping [1.64s, exited with code 1]
Summary: 0 packages finished [3.00s]
cd ~/gmapping_ws/src
rm -rf gmapping
rm -rf openslam_gmapping
ls
git clone https://github.com/Project-MANAS/slam_gmapping_ros2.git
ping 192.168.0.194
source ~/.bashrc
tmux
ssh pi@<pi_ip>
tmux new -s mapping
sudo apt update
sudo apt upgrade -y
echo $ROS_DISTRO
sudo apt install ros-humble-nav2-map-server -y
sudo apt install ros-humble-nav2-bringup -y
sudo apt install -y ros-humble-tf2-tools ros-humble-robot-state-publisher ros-humble-joint-state-publisher ros-humble-rviz2
ls /opt/ros/humble/share/slam_toolbox/config/
tmux new -s slam
git clone https://github.com/Project-MANAS/slam_gmapping_ros2.git
tmux
sudo apt install ros-humble-slam-toolbox -y
ros2 pkg list | grep slam
sudo poweroff
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 base_link laser
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 odom base_link
ros2 run tf2_tools view_frames
ls
sudo apt install mupdf-tools -y
mutool draw -F text file.pdf
scp rospi@192.168.0.199:~/frames_2025-12-16_13.55.58.pdf
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 odom base_link
ros2 launch rplidar_ros rplidar_a1_launch.py frame_id:=laser
ros2 launch rplidar_ros rplidar_a1_launch.py 
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 odom base_link
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 base_link laser
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 base_link laser
ls
nano ~/handheld_slam.yaml
ros2 launch slam_toolbox online_sync_launch.py slam_params_file:=/home/$USER/handheld_slam.yaml
ros2 launch slam_toolbox online_sync_launch.py
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 odom base_link
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 base_link laser
tmux
source ~/.bashrc
ros2 launch rplidar_ros rplidar_a1_launch.py 
cd
ls
nano ~/.bashrc
source ~/ros2_ws/install/setup.bash 
ros2 launch rplidar_ros rplidar_a1_launch.py 
ros2 launch slam_toolbox online_sync_launch.py slam_params_file:=/home/$USER/handheld_slam.yaml
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 odom base_link
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 base_link laser
sudo poweroff
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 base_link laser
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 odom base_link
source ~/.bashrc
ros2 launch rplidar_ros rplidar_a1_launch.py frame_id:=laser
ros2 launch rplidar_ros rplidar_a1_launch.py 
ros2 topic hz /map
ros2 launch rplidar_ros rplidar_a1_launch.py
nano ~/slam_a1_handheld.yaml
ros2 launch slam_toolbox online_sync_launch.py slam_params_file:=/home/$USER/slam_a1_handheld.yaml
nano ~/slam_a1_handheld.yaml
clear
ros2 launch slam_toolbox online_sync_launch.py slam_params_file:=/home/$USER/slam_a1_handheld.yaml
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 odom base_link
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 base_link laser
ls
sudo apt update
sudo apt install -y ros-humble-tf2-ros ros-humble-nav-msgs ros-humble-geometry-msgs
mkdir -p ~/hector_ws/src
cd ~/hector_ws/src
cd ~/hector_ws
rosdep install --from-paths src --ignore-src -r -y
source /opt/ros/humble/setup.bash
colcon build
source install/setup.bash
mkdir -p ~/hector_ws/src
cd ~/hector_ws/src
git clone https://github.com/tu-darmstadt-ros-pkg/hector_slam.git -b ros2
cd
tmux
cd ros2_ws/
ls
cd src/
ls
cd rplidar_ros/
ls
cd launch/
l
nano rplidar_a1_launch.py 
cd ..
ls
cd src/
ls
cd ..
ls
cd include/
l
cd ..
l
cd debian/
ls
cd
sudo apt install ros-humble-rmw-cyclonedds-cpp
nano .bashrc
clear
sudo apt install ros-humble-navigation2 ros-humble-nav2-bringup ros-humble-turtlebot3*
cd
ls
rm frames_2025-12-16_13.55.58.
rm frames_2025-12-16_13.55.58.pdf 
ls
rm slam_a1_handheld.yaml 
rm -rf rplidar_ws_src.tar.xz 
ls
rm 'view?usp=drive_link' 
ls
rm -rf nomachine.deb 
ls
rm handheld_slam.yaml 
rm frames_2025-12-16_13.55.58.gv 
ls
rm -rf my_robot_bringup/
rm -rf ros2_rplidar_ws/
rm -rf src/
;s
ls
mkdir -p ~/ros2_ws/src
cd ~/ros2_ws/src
git clone https://github.com/Slamtec/sllidar_ros2.git
cd ~/ros2_ws
sudo rosdep update
rosdep install --from-paths src --ignore-src -r -y
# Build
colcon build --symlink-install
ros2 launch sllidar_ros2 sllidar_a1_launch.py serial_port:=/dev/ttyUSB0 serial_baudrate:=115200 frame_id:=laser
source ~/ros2_ws/install/setup.bash
ros2 launch sllidar_ros2 sllidar_a1_launch.py serial_port:=/dev/ttyUSB0 serial_baudrate:=115200 frame_id:=laser
ros2 launch sllidar_ros2 sllidar_a1_launch.py
cd src/
ls
cd sllidar_ros2/
ls
cd launch/
ls
cd
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
ls -l /dev | grep ttyUSB
# Suppose it’s /dev/ttyUSB0
sudo chmod 666 /dev/ttyUSB0
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
ls /dev/ttyUSB*
sudo usermod -a -G dialout $USER
sudo chmod 666 /dev/ttyUSB0
sudo reboot
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 base_link laser
ros2 topic echo /scan | head -n 5
ros2 topic list | grep odom
ros2 topic echo /odom
clear
cd ros2_ws/
ls
cd src/
ls
cd fake_robot_base/
ls
cd fake_robot_base/
ls
nano fake_odom.py 
cd ~/ros2_ws
colcon build
source install/setup.bash
nano ~/ros2_ws/src/fake_robot_base/fake_robot_base/fake_base_controller.py
chmod +x ~/ros2_ws/src/fake_robot_base/fake_robot_base/fake_base_controller.py
nano ~/ros2_ws/src/fake_robot_base/setup.py
cd ~/ros2_ws
colcon build
source install/setup.bash
sudo apt install ros-humble-teleop-twist-keyboard
ros2 run teleop_twist_keyboard teleop_twist_keyboard
sudo apt install -y ros-humble-navigation2 ros-humble-nav2-bringup
cd ~/ros2_ws/src
ros2 pkg create fake_robot_base --build-type ament_python
nano ~/ros2_ws/src/fake_robot_base/fake_robot_base/fake_odom.py
chmod +x ~/ros2_ws/src/fake_robot_base/fake_robot_base/fake_odom.py
nano ~/ros2_ws/src/fake_robot_base/setup.py
cd ~/ros2_ws
colcon build
source install/setup.bash
cd
ros2 run fake_robot_base fake_odom
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
ros2 topic list
ros2 run tf2_tools view_frames
ls
ros2 topic echo /scan | head -n 5
ros2 topic echo /scan
ros2 topic echo /scan | head -n 5
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 base_link laser
sudo apt install -y ros-humble-slam-toolbox
ros2 launch slam_toolbox online_async_launch.py
ros2 run teleop_twist_keyboard teleop_twist_keyboard
ros2 launch slam_toolbox online_async_launch.py slam_params_file:=~/slam_fake.yaml
nano ~/slam_fake.yaml
ros2 launch slam_toolbox online_async_launch.py slam_params_file:=~/slam_fake.yaml
nano ~/slam_fake.yaml
source ~/ros2_ws/install/setup.bash
ros2 launch slam_toolbox online_async_launch.py slam_params_file:=/home/rospi/slam_fake.yaml
ros2 run fake_robot_base fake_base
~
ros2 run fake_robot_base fake_base
cd ros2_ws/src/
l
cd f
cd fake_robot_base/
ls
cd fake_robot_base/
ls
python3 fake_odom.py 
python3 fake_base_controller.py 
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 base_link laser
ros2 launch sllidar_ros2 sllidar_a1_launch.py
nano .bashrc 
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
cd
ls
source ~/ros2_ws/install/setup.bash
ros2 launch sllidar_ros2 sllidar_a1_launch.py serial_port:=/dev/ttyUSB0 serial_baudrate:=115200 frame_id:=laser
ros2 launch sllidar_ros2 sllidar_a1_launch.py
sudo apt install -y ros-humble-slam-toolbox
tmux
sudo poweroff
ros2 run arduino_motor_odom arduino_base
ls /dev/tty*
sudo apt install python3-serial
cd ~/ros2_ws/src
ros2 pkg create arduino_motor_odom --build-type ament_python
nano ~/ros2_ws/src/arduino_motor_odom/arduino_motor_odom/arduino_node.py
chmod +x ~/ros2_ws/src/arduino_motor_odom/arduino_motor_odom/arduino_node.py
cd ~/ros2_ws/src/arduino_motor_odom/setup.py
ls
cd arduino_motor_odom/
ls
nano setup.py 
cd ~/ros2_ws
colcon build
source install/setup.bash
tmux
ls /dev/tty*
/dev/ttyAMA0
ls /dev/tty*
/dev/ttyAMA0
ls /dev/tty*
sudo modprobe cdc_acm
ls /dev/ttyACM*
dmesg | tail -40
ls /dev/ttyACM*
sudo usermod -a -G dialout $USER
sudo reboot
groups
nano ~/ros2_ws/src/arduino_motor_odom/arduino_motor_odom/arduino_node.py
cd ~/ros2_ws
colcon build
source install/setup.bash
tmux
ros2 run arduino_motor_odom arduino_base
tmux ls
ros2 run arduino_motor_odom arduino_base
ros2 topic echo /odom
ros2 topic list
screen /dev/ttyUSB1 115200
ros2 run teleop_twist_keyboard teleop_twist_keyboard
ros2 run arduino_motor_odom arduino_base
clear
ros2 run arduino_motor_odom arduino_base
ls /dev/tty
ls /dev/tty0
ls /dev/tty*
ros2 run arduino_motor_odom arduino_base
ls /dev/tty*
ros2 run arduino_motor_odom arduino_base
nano ~/ros2_ws/src/arduino_motor_odom/arduino_motor_odom/arduino_node.py
ls /dev/tty*
ros2 run arduino_motor_odom arduino_base
nano ~/ros2_ws/src/arduino_motor_odom/arduino_motor_odom/arduino_node.py
ros2 run arduino_motor_odom arduino_base
nano ~/ros2_ws/src/arduino_motor_odom/arduino_motor_odom/arduino_node.py
ros2 run arduino_motor_odom arduino_base
nano ~/ros2_ws/src/arduino_motor_odom/arduino_motor_odom/arduino_node.py
ros2 run arduino_motor_odom arduino_base
nano ~/ros2_ws/src/arduino_motor_odom/arduino_motor_odom/arduino_node.py
ros2 run arduino_motor_odom arduino_base
exit
ros2 run arduino_motor_odom arduino_base
ls /dev/tty*
nano ~/ros2_ws/src/arduino_motor_odom/arduino_motor_odom/arduino_node.py
ls /dev/tty*
ros2 run arduino_motor_odom arduino_base
chmod +x ~/ros2_ws/src/arduino_motor_odom/arduino_motor_odom/arduino_node.py
ros2 run arduino_motor_odom arduino_base
nano ~/ros2_ws/src/arduino_motor_odom/arduino_motor_odom/arduino_node.py
cd ~/ros2_ws
colcon build
source install/setup.bash
ros2 run arduino_motor_odom arduino_base
ros2 run teleop_twist_keyboard teleop_twist_keyboard
nano ~/ros2_ws/src/arduino_motor_odom/arduino_motor_odom/arduino_node.py
exit
ros2 run arduino_motor_odom arduino_base
ros2 run teleop_twist_keyboard teleop_twist_keyboard
ros2 run rc_car_control rc_car
ros2 run teleop_twist_keyboard teleop_twist_keyboard
clear
ros2 run rc_car_control rc_car
chmod +x ~/ros2_ws/src/arduino_motor_odom/arduino_motor_odom/arduino_node.py
ros2 run rc_car_control rc_car
clear
ros2 run rc_car_control rc_car
ros2 run teleop_twist_keyboard teleop_twist_keyboard
ros2 run rc_car_control rc_car
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
ros2 run teleop_twist_keyboard teleop_twist_keyboard
ros2 topic list
cd ~/ros2_ws
colcon build
source install/setup.bash
~
ros2 topic echo /odom
ros2 topic echo /cmd_vel
clear
ros2 topic echo /cmd_vel
ros2 topic echo /scan
clear
ros2 topic echo /scan
celar
clear
ros2 run tf2_ros static_transform_publisher 0 0 0.1 0 0 0 base_link laser
nano ~/slam_rc.yaml
ros2 launch slam_toolbox online_async_launch.py slam_params_file:=/home/rospi/slam_rc.yaml
ros2 run teleop_twist_keyboard teleop_twist_keyboard
ros2 run rc_car_control rc_car
ros2 run teleop_twist_keyboard teleop_twist_keyboard
ros2 run tf2_ros static_transform_publisher 0 0 0.1 0 0 0 base_link laser
ros2 run rc_car_control rc_car
clear
ros2 run rc_car_control rc_car
ros2 launch slam_toolbox online_async_launch.py slam_params_file:=/home/rospi/slam_rc.yaml
ros2 topic echo /odom
clear
ros2 launch sllidar_ros2 sllidar_a1_launch.py
ros2 run nav2_map_server map_saver_cli -f ~/my_map
ls
cd
ls
nano ~/nav2_rc.yaml
ros2 launch nav2_bringup navigation_launch.py params_file:=/home/rospi/nav2_rc.yaml
clear
nano ~/nav2_rc.yaml
ros2 launch nav2_bringup navigation_launch.py params_file:=/home/rospi/nav2_rc.yaml
tmux ls
robot: 1 windows (created Tue)
tmux attach -t robot
tmux attach -t 1
tmux kill-session -t robot
tmux kill-session
ros2 run arduino_motor_odom arduino_base
cd ros2_ws/
ros2 run arduino_motor_odom arduino_base
ls
cd src/
ls
cd arduino_motor_odom/
ls
cd arduino_motor_odom/
ls
ros2 run arduino_motor_odom arduino_base
ros2 run arduino_motor_odom arduino_node
nano ~/ros2_ws/src/arduino_motor_odom/arduino_motor_odom/arduino_node.py
cd ..
colcon build
source install/setup.bash
ros2 run arduino_motor_odom arduino_base
clear
ros2 run arduino_motor_odom arduino_base
Traceback (most recent call last):
TabError: inconsistent use of tabs and spaces in indentation
[ros2run]: Process exited with failure 1
nano ~/ros2_ws/src/arduino_motor_odom/arduino_motor_odom/arduino_node.py
ros2 run arduino_motor_odom arduino_base
nano ~/ros2_ws/src/arduino_motor_odom/arduino_motor_odom/arduino_node.py
cd ~/ros2_ws
colcon build
source install/setup.bash
ros2 run arduino_motor_odom arduino_base
tmux
nano ~/ros2_ws/src/arduino_motor_odom/arduino_motor_odom/arduino_node.py
cd ~/ros2_ws
colcon build
source install/setup.bash
tmux
clear
cd ~/ros2_ws/src
ros2 pkg create rc_car_control --build-type ament_python
nano ~/ros2_ws/src/rc_car_control/rc_car_control/rc_car_node.py
chmod +x ~/ros2_ws/src/rc_car_control/rc_car_control/rc_car_node.py
nano ~/ros2_ws/src/rc_car_control/setup.py
cd ~/ros2_ws
colcon build
source install/setup.bash
tmux
nano ~/ros2_ws/src/rc_car_control/setup.py
nano ~/ros2_ws/src/rc_car_control/rc_car_control/rc_car_node.py
chmod +x ~/ros2_ws/src/rc_car_control/rc_car_control/rc_car_node.py
colcon build
tmux
nano ~/ros2_ws/src/rc_car_control/rc_car_control/rc_car_node.py
colcon build
tmux
chmod +x ~/ros2_ws/src/rc_car_control/rc_car_control/rc_car_node.py
ros2 run rc_car_control rc_car
chmod +x ~/ros2_ws/src/rc_car_control/rc_car_control/rc_car_node.py
nano ~/ros2_ws/src/rc_car_control/rc_car_control/rc_car_node.py
ls /dev/tty*
tmux
nano ~/ros2_ws/src/rc_car_control/rc_car_control/rc_car_node.py
tmux
colcon build
tmux
nano ~/ros2_ws/src/rc_car_control/rc_car_control/rc_car_node.py
cd ~/ros2_ws
colcon build
source install/setup.bash
tmux
nano ~/ros2_ws/src/rc_car_control/rc_car_control/rc_car_node.py
cd ~/ros2_ws
colcon build
source install/setup.bash
tmux
nano ~/ros2_ws/src/rc_car_control/rc_car_control/rc_car_node.py
colcon build
tmux
nano ~/ros2_ws/src/rc_car_control/rc_car_control/rc_car_node.py
colcon build
tmux
cd
ls
sudo poweroff
ros2 run rc_car_control rc_car
cd ros2_ws/
source install/setup.bash 
ros2 run rc_car_control rc_car
ros2 launch sllidar_ros2 sllidar_a1_launch.py
source ~/.bashrc
ros2 launch sllidar_ros2 sllidar_a1_launch.py
cd ros2_ws/
source install/setup.bash 
ros2 launch sllidar_ros2 sllidar_a1_launch.py
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
cd
nano .bashrc
source /opt/ros/humble/setup.bash
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
source /opt/ros/humble/setup.bash
cd ros2_ws/
ls
source install/setup.bash
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
clear
ps aux | grep lidar
sudo killall sllidar_node
ps aux | grep lidar
ls /dev/ttyUSB*
sudo chmod 666 /dev/ttyUSB0
ros2 launch sllidar_ros2 sllidar_a1_launch.py serial_port:=/dev/ttyUSB0 serial_baudrate:=115200
ros2 launch sllidar_ros2 sllidar_a1_launch.py
sudo apt install rplidar-tools
rplidar_test /dev/ttyUSB0
ros2 launch sllidar_ros2 sllidar_a1_launch.py
source /opt/ros/humble/setup.bash
source install/setup.bash
cd
nano .bashrc 
ros2 launch sllidar_ros2 sllidar_a1_launch.py
source ~/.bashrc
ros2 launch sllidar_ros2 sllidar_a1_launch.py
tmux
clear
sudo shutdown now
clear
source ~/.bashrc
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
tmux ls
tmux kill-server
screen -ls
pkill screen
jobs
kill $(jobs -p)
ros2 node list
pkill -f ros2
pkill -f rclpy
pkill -f rclcpp
pkill sllidar_node
pkill -f serial
sudo lsof /dev/ttyUSB0
sudo kill -9 <PID>
tmux kill-server
pkill -f ros2
pkill -f lidar
sudo reboot
source ~/.bashrc 
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
tmux
nano ~/slam_rc.yaml
clear
ros2 launch sllidar_ros2 sllidar_a1_launch.py
source ~/.bashrc
ros2 launch sllidar_ros2 sllidar_a1_launch.py
ls /dev/ttyUSB*
sudo reboot
ros2 run rc_car_control rc_car
ros2 launch sllidar_ros2 sllidar_a1_launch.py
ros2 run tf2_ros static_transform_publisher 0 0 0.1 0 0 0 base_link laser
ros2 run tf2_ros static_transform_publisher 0 0 0.1 0 0 0 base_link laser
ros2 run rc_car_control rc_car
ros2 launch nav2_bringup navigation_launch.py params_file:=/home/rospi/nav2_rc.yaml
ros2 run teleop_twist_keyboard teleop_twist_keyboard 
source ~/.bashrc
tmux
sudo reboot
ros2 launch slam_toolbox online_async_launch.py
ros2 topic list
ros2 launch slam_toolbox online_async_launch.py
nano ~/slam_rc.yaml
ros2 run rc_car_control rc_car 
clear
ros2 run rc_car_control rc_car 
ls /dev/tty*
ros2 run rc_car_control rc_car 
ros2 run rc_car_control rc_car
ls /dev/tty*
ros2 run rc_car_control rc_car
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
source ~/.bashrc
tmux
sudo reboot
ls /dev/tty*
ros2 run rc_car_control rc_car 
ls /dev/tty*
ros2 run teleop_twist_keyboard teleop_twist_keyboard 
ros2 launch rplidar_ros rplidar.launch.py
source ~/.bashrc
ros2 launch rplidar_ros rplidar.launch.py
clear
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
ros2 run rc_car_control rc_car
ros2 run tf2_ros static_transform_publisher 0 0 0.1 0 0 0 base_link laser
ros2 launch slam_toolbox online_async_launch.py slam_params_file:=/home/rospi/slam_rc.yaml
udevadm info -a -n /dev/ttyUSB0 | grep '{idVendor}\|{idProduct}\|{serial}' | head -n 20
ls /dev/tty*
udevadm info -a -n /dev/ttyUSB0 | grep '{idVendor}\|{idProduct}\|{serial}' | head -n 20
sudo nano /etc/udev/rules.d/99-usb-serial.rules
cd
clear
ls /dev/tty*
tmux
source ~/.bashrc 
tmux
ls /dev/tty*
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
ls /dev/tty*
ls /dev/ttyUSB*
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
udevadm info -a -n /dev/ttyUSB0 | grep '{idVendor}\|{idProduct}\|{serial}' | head -n 20
sudo nano /etc/udev/rules.d/99-robot-usb.rules
sudo udevadm control --reload-rules
sudo udevadm trigger
ls -l /dev/lidar
ls /dev/ttyUSB*
udevadm info -a -n /dev/ttyUSB1 | grep '{idVendor}\|{idProduct}\|{serial}'
sudo nano /etc/udev/rules.d/99-robot-usb.rules
sudo udevadm control --reload-rules
sudo udevadm trigger
ls -l /dev/lidar /dev/arduino
ros2 launch sllidar_ros2 sllidar_a1_launch.py serial_port:=/dev/lidar
cd ros2_ws/src/sllidar_ros2/
ls
cd launch/
ls
nano sllidar_a1_launch.py 
cd
ros2 launch sllidar_ros2 sllidar_a1_launch.py serial_port:=/dev/lidar
ros2 launch sllidar_ros2 sllidar_a1_launch.py
cd ros2_ws/src/rc_car_control/
ls
cd rc_car_control/
ls
nano rc_car_node.py 
cd
tmux
sudo poweroff now
sudo poweroff
ros2 run tf2_ros tf2_echo odom base_link
ros2 launch slam_toolbox online_async_launch.py slam_params_file:=~/slam_rc.yaml
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
ros2 run tf2_ros static_transform_publisher 0 0 0.1 0 0 0 base_link laser
ros2 run rc_car_control rc_car
ros2 launch slam_toolbox online_async_launch.py slam_params_file:=~/slam_rc.yaml
ros2 run tf2_ros static_transform_publisher 0 0 0.0 0 0 0 base_link laser
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
ros2 run rc_car_control rc_car 
~/ros2_ws/src/rc_car_control/rc_car_control/rc_car_node.py
nano ~/ros2_ws/src/rc_car_control/rc_car_control/rc_car_node.py
nano ~/slam_rc.yaml
source ~/.bashrc
tmux
nano ~/ros2_ws/src/rc_car_control/rc_car_control/rc_car_node.py
nano ~/slam_rc.yaml
cd ros2_ws/
colcon build
cd
tmux
sudo poweroff
tmux
ros2 run robot_motor motor_node
ros2 topic list
ros2 run robot_odometry odom_node
nano ~/ros2_ws/src/robot_odometry/robot_odometry/odom_node.py
cd ~/ros2_ws
colcon build
source install/setup.bash
cd
source ~/.bashrc
ros2 run robot_odometry odom_node
tmux
nano ~/ros2_ws/src/odom_lm393/odom_lm393/odom_lm393_node.py
clear
cd ~/ros2_ws
colcon build
source install/setup.bash
source ~/.bashrc
ros2 run odom_lm393 odom_lm393_node 
cleaaar
clear
ros2 run odom_lm393 odom_lm393_node 
source ~/.bashrc
ros2 run robot_state_publisher robot_state_publisher ~/ros2_ws/src/odom_lm393/urdf/simple_robot.urdf
clear
ros2 run teleop_twist_keyboard teleop_twist_keyboard 
ros2 launch sllidar_ros2 sllidar_a1_launch.py
~
ros2 run odom_lm393 odom_lm393_node
ros2 launch sllidar_ros2 sllidar_a1_launch.py
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
cd ros2_ws/src/sllidar_ros2/launch/
ls
nano sllidar_a1_launch.py 
cd
ls /dev/lidar
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
cd
clear
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
ls dev/tty*
ls dev/ttyUSB
ls dev/
ll dev/tty*
cd
source ~/.bashrc
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
ls
ls /dev/ttyUSB
ls /dev/tty*
ls /dev/ttyUSB*
ls
ls /dev/arduino
ls /dev/lidar
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
tmux
source ~/.bashrc
tmux
sudo reboot
ros2 run odom_lm393 odom_lm393_node
ros2 launch sllidar_ros2 sllidar_a1_launch.py
ros2 launch slam_toolbox online_async_launch.py slam_params_file:=/home/rospi/slam_lm393.yaml
ros2 run teleop_twist_keyboard teleop_twist_keyboard
ros2 run tf2_ros static_transform_publisher 0 0 0.1 0 0 0 base_link laser
ros2 run teleop_twist_keyboard teleop_twist_keyboard 
ros2 launch slam_toolbox online_async_launch.py slam_params_file:=/home/rospi/slam_lm393.yaml
ros2 run tf2_ros static_transform_publisher 0 0 0.1 0 0 0 base_link laser
ros2 run odom_lm393 odom_lm393_node 
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
ros2 run tf2_ros static_transform_publisher 0.0 0.0 0.1 0 0 0 base_link laser
ros2 run teleop_twist_keyboard teleop_twist_keyboard 
ros2 run odom_lm393 odom_lm393_node 
ros2 launch slam_toolbox online_async_launch.py slam_params_file:=/home/rospi/slam_lm393.yaml
ros2 launch slam_toolbox online_async_launch.py slam_params_file:=/home/rospi/slam/slam_lm393.yaml
ros2 launch sllidar_ros2 sllidar_a1_launch.py scan_mode:=Standard
ros2 run odom_lm393 odom_lm393_node
ros2 run tf2_ros static_transform_publisher 0 0 0.1 0 0 0 base_link laser
ros2 run teleop_twist_keyboard teleop_twist_keyboard 
ros2 launch slam_toolbox online_async_launch.py slam_params_file:=/home/rospi/slam/slam_lm393.yaml
mkdir -p ~/maps
cd ~/maps
ros2 run nav2_map_server map_saver_cli -f my_map
cd
sudo apt install ros-humble-nav2-map-server
nano ~/ros2_ws/src/odom_lm393/odom_lm393/odom_lm393_node.py 
cd ros2_ws/
colcon build
mkdir -p ~/nav2
nano ~/nav2/nav2_lm393.yaml
ros2 launch nav2_bringup navigation_launch.py use_sim_time:=false params_file:=/home/rospi/nav2/nav2_lm393.yaml
cd
nano ~/nav2/nav2_lm393.yaml
ros2 launch nav2_bringup navigation_launch.py use_sim_time:=false params_file:=/home/rospi/nav2/nav2_lm393.yaml
ros2 launch nav2_bringup navigation_launch.py use_sim_time:=false params_file:=/home/rospi/nav2/nav2_lm393.yaml
ls ~/maps/my_map.yaml
ros2 launch sllidar_ros2 sllidar_a1_launch.py
clear
ros2 launch sllidar_ros2 sllidar_a1_launch.py
ros2 run tf2_ros static_transform_publisher 0 0 0.1 0 0 0 base_link laser
ros2 run odom_lm393 odom_lm393_node
ros2 launch nav2_bringup navigation_launch.py use_sim_time:=false params_file:=/home/rospi/nav2/nav2_lm393.yaml
ros2 launch sllidar_ros2 sllidar_a1_launch.py
ros2 run tf2_ros static_transform_publisher 0 0 0.1 0 0 0 base_link laser
ros2 run tf2_ros tf2_echo map odom
ros2 node list | grep amcl
ros2 topic echo /map --once
ros2 node list
ls /home/rospi/maps/my_map.yaml
ls /home/rospi/maps/my_map.pgm
ros2 topic list | grep scan
ros2 topic echo /odom --once
nano ~/nav2/nav2_lm393.yaml
ros2 launch nav2_bringup navigation_launch.py use_sim_time:=false params_file:=/home/rospi/nav2/nav2_lm393.yaml
ros2 launch nav2_bringup bringup_launch.py use_sim_time:=false map:=/home/rospi/maps/my_map.yaml params_file:=/home/rospi/nav2/nav2_lm393.yaml
ros2 launch sllidar_ros2 sllidar_a1_launch.py
ros2 run tf2_ros static_transform_publisher 0 0 0.1 0 0 0 base_link laser
clear
ros2 run odom_lm393 odom_lm393_node
ros2 launch robot_nav nav2_bringup_lm393.launch.py use_sim_time:=false map:=/home/rospi/maps/my_map.yaml params_file:=/home/rospi/nav2/nav2_lm393.yaml
nano ~/ros2_ws/src/robot_nav/setup.py
ls ~/ros2_ws/src/robot_nav/launch
cd ~/ros2_ws
rm -rf build install log
colcon build
cd
ros2 launch robot_nav nav2_bringup_lm393.launch.py use_sim_time:=false map:=/home/rospi/maps/my_map.yaml params_file:=/home/rospi/nav2/nav2_lm393.yaml
ros2 launch sllidar_ros2 sllidar_a1_launch.py
ros2 run tf2_ros static_transform_publisher 0 0 0.1 0 0 0 base_link laser
ros2 node list
nano ~/nav2/nav2_lm393.yaml
ros2 node list
clear
cd ~/ros2_ws/src
ros2 pkg create robot_nav --build-type ament_python
mkdir -p ~/ros2_ws/src/robot_nav/launch
nano ~/ros2_ws/src/robot_nav/launch/nav2_bringup_lm393.launch.py
cd ~/ros2_ws
colcon build
source install/setup.bash
cd ros2_ws/src/odom_lm393/odom_lm393/
nano odom_lm393_node.py 
cd ..
colcon build
cd
source ~/.bashrc
tmux
cd
sudo poweroff
tmux
source ~/.bashrc
ls
rm my_map.pgm 
rm my_map.yaml 
ls
rm frames_2025-12-17_12.17.31.gv 
rm frames_2025-12-17_12.17.31.pdf 
ls
cd
clear
tmux
ros2 run odom_lm393 odom_lm393_node 
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
ros2 launch robot_nav nav2_bringup_lm393.launch.py use_sim_time:=false map:=/home/rospi/maps/my_map.yaml params_file:=/home/rospi/nav2/nav2_lm393.yaml
ros2 run tf2_ros static_transform_publisher 0 0 0.1 0 0 0 base_link laser
source ~/.bashrc
tmux
ros2 launch nav2_bringup bringup_launch.py use_sim_time:=false map:=/home/rospi/maps/my_map.yaml params_file:=/home/rospi/nav2/nav2_lm393.yaml
ros2 launch sllidar_ros2 sllidar_a1_launch.py
ros2 run tf2_ros static_transform_publisher 0 0 0.1 0 0 0 base_link laser
ros2 run odom_lm393 odom_lm393_node
clear
ros2 run odom_lm393 odom_lm393_node
clear
ls
cd
ros2 topic echo /odom
ls
ros2 launch robot_nav nav2_bringup_lm393.launch.py use_sim_time:=false map:=/home/rospi/maps/my_map.yaml params_file:=/home/rospi/nav2/nav2_lm393.yaml
ls
ros2 run odom_lm393 odom_lm393_node
cd ~/ros2_ws
colcon build
source install/setup.bash
clear
ros2 run odom_lm393 odom_lm393_node
nano ~/ros2_ws/src/odom_lm393/odom_lm393/odom_lm393_node.py
clear
ros2 run tf2_ros static_transform_publisher 0 0 0.1 0 0 0 base_link laser
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
ros2 run tf2_ros static_transform_publisher 0 0 0.1 0 0 0 base_link laser
clear
ros2 run tf2_ros static_transform_publisher 0 0 0.1 0 0 0 base_link laser
ros2 run odom_lm393 odom_lm393_node 
clear
ros2 run odom_lm393 odom_lm393_node 
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
clear
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
sudo poweroff
ros2 launch robot_nav nav2_bringup_lm393.launch.py 
map:=/home/rospi/maps/my_map.yaml params_file:=/home/rospi/nav2/nav2_lm393.yaml
ros2 launch robot_nav nav2_bringup_lm393.launch.py 
ros2 launch robot_nav nav2_bringup_lm393.launch.py use_sim_time:=false map:=/home/rospi/maps/my_map.yaml params_file:=/home/rospi/nav2/nav2_lm393.yaml
ros2 launch slam_toolbox online_async_launch.py 
ros2 launch robot_nav nav2_bringup_lm393.launch.py use_sim_time:=false map:=/home/rospi/maps/my_map.yaml params_file:=/home/rospi/nav2/nav2_lm393.yaml
clear
ros2 launch robot_nav nav2_bringup_lm393.launch.py use_sim_time:=false map:=/home/rospi/maps/my_map.yaml params_file:=/home/rospi/nav2/nav2_lm393.yaml
sudo apt update
sudo apt install python3-colcon-common-extensions git -y
mkdir -p ~/micro_ros_ws/src
cd ~/micro_ros_ws/src
git clone -b humble https://github.com/micro-ROS/micro_ros_espidf_component.git
cd ..
colcon build
source install/setup.bash
rm -rf ~/micro_ros_ws
ls
cd
ls
sudo apt update
sudo apt install ros-humble-micro-ros-agent
sudo apt update
sudo apt install software-properties-common -y
sudo add-apt-repository universe
sudo apt update
ls /etc/apt/sources.list.d/
sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key   -o /usr/share/keyrings/ros-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] \
http://packages.ros.org/ros2/ubuntu $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null
sudo apt update
sudo grep -R "BEGIN PGP" /etc/apt
sudo nano /etc/apt/sources.list.d/ros2.list
sudo rm /etc/apt/sources.list.d/ros2.list
sudo mkdir -p /usr/share/keyrings
sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key -o /usr/share/keyrings/ros-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] \
http://packages.ros.org/ros2/ubuntu jammy main" | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null
sudo add-apt-repository universe
sudo apt update
sudo grep -R "PGP PUBLIC KEY BLOCK" /etc/apt
sudo rm /etc/apt/sources.list.d/ros2.list
sudo nano /etc/apt/sources.list
sudo rm -rf /var/lib/apt/lists/*
sudo apt clean
sudo add-apt-repository universe
sudo apt update
sudo mkdir -p /usr/share/keyrings
sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key -o /usr/share/keyrings/ros-archive-keyring.gpg
sudo apt update
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] \
http://packages.ros.org/ros2/ubuntu jammy main" | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null
sudo apt update
sudo apt install ros-humble-micro-ros-agent
sudo grep -R "PGP PUBLIC KEY BLOCK" /etc/apt
sudo rm /etc/apt/sources.list.d/ros2.list
sudo grep -R "PGP PUBLIC KEY BLOCK" /etc/apt
sudo rm /etc/apt/sources.list.d/ros2.sources
sudo grep -R "PGP PUBLIC KEY BLOCK" /etc/apt
sudo nano /etc/apt/sources.list
sudo rm -rf /var/lib/apt/lists/*
sudo apt clean
sudo apt update
sudo add-apt-repository universe
sudo apt update
sudo apt install ros-humble-micro-ros-agent
ros2 run micro_ros_agent micro_ros_agent --help
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
newgrp docker
ros2 topic list
ros2 topic list -t
ros2 node list
ros2 topic echo /rosout
docker run -it --rm   --privileged   --net=host   -v /dev:/dev   microros/micro-ros-agent:humble   serial --dev /dev/ttyUSB0
clear
docker run -it --rm   --privileged   --net=host   -v /dev:/dev   microros/micro-ros-agent:humble   serial --dev /dev/ttyUSB0 -v 2
docker run -it --rm   --privileged   --net=host   -v /dev:/dev   microros/micro-ros-agent:humble   serial --dev /dev/ttyUSB0
docker run -it --rm   --privileged   --net=host   -v /dev:/dev   microros/micro-ros-agent:humble   serial --dev /dev/ttyUSB0 -v 2
docker run -it --rm   --privileged   --net=host   -v /dev:/dev   microros/micro-ros-agent:humble   serial --dev /dev/ttyUSB0
ls /dev/ttyUSB*
sudo usermod -aG dialout $USER
docker run -it --rm   --privileged   --net=host   -v /dev:/dev   microros/micro-ros-agent:humble   serial --dev /dev/ttyUSB0
tmux
git clone https://github.com/linorobot/linorobot2.git
cd linorobot2/docker
docker compose build
ls
cd
ls
rm -rf linorobot2/
ls
ros2 run obstacle_avoidance.py 
python3 obstacle_avoidance.py 
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
ros2 run robot_motor motor_node
nano ~/ros2_ws/src/robot_motor/setup.py
nano ~/ros2_ws/src/robot_motor/robot_motor/motor_node.py
ros2 run robot_avoidance avoidance_node
nano ~/ros2_ws/src/robot_avoidance/setup.py
cd ~/ros2_ws
rm -rf build install log
colcon build --symlink-install
source install/setup.bash
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
cd
ls
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
ros2 launch rplidar_ros rplidar.launch.py
ros2 run robot_motor motor_node
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
newgrp docker
clear
cd ~/ros2_ws/src
git clone https://github.com/Slamtec/rplidar_ros.git
cd ..
colcon build
source install/setup.bash
ls
cd src/
ls
rm -rf rplidar_ros/
ls
cd sllidar_ros2/l
cd sllidar_ros2/
l
cd
source ~/.bashrc
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
cd
ls
cd ros2_ws/
ls
cd src/
ls
cd rc
ls
cd
nano obstacle_avoidance.py
tmux
mkdir -p ~/ros2_ws/src
cd ~/ros2_ws/src
ros2 pkg create robot_motor --build-type ament_python --dependencies rclpy geometry_msgs
ls
rm -rf robot_motor/
ros2 pkg create robot_motor --build-type ament_python --dependencies rclpy geometry_msgs
ros2 pkg create robot_avoidance --build-type ament_python --dependencies rclpy sensor_msgs geometry_msgs
nano robot_motor/robot_motor/motor_node.py
nano robot_avoidance/robot_avoidance/avoidance_node.py
cd ~/ros2_ws
colcon build
source install/setup.bash
cd
tmux
sudo apt update
sudo apt install -y python3-rpi.gpio
clear
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
sudo poweroff
clear
ros2 run robot_motor motor_node
ros2 run robot_avoidance avoidance_node
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
ros2 run robot_motor motor_node
ros2 run robot_avoidance avoidance_node
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
ros2 run robot_avoidance avoidance_node
ros2 run robot_motor motor_node
ros2 run robot_avoidance avoidance_node
nano ~/ros2_ws/src/robot_motor/robot_motor/motor_node.py
cd ros2_ws/
colcon build
cd
clear
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
ros2 run robot_motor motor_node
clear
ros2 run robot_motor motor_node
clear
ros2 run robot_motor motor_node
clear
ros2 run robot_motor motor_node
ros2 run robot_avoidance avoidance_node
clear
ros2 run robot_avoidance avoidance_node
clear
ros2 run robot_avoidance avoidance_node
clear
ros2 run robot_avoidance avoidance_node --ros-args -p speed_mode:=slow
clear
ros2 run robot_motor motor_node
nano robot_motor/robot_motor/motor_node.py
cd ros2_ws/src/
nano robot_motor/robot_motor/motor_node.py
nano robot_avoidance/robot_avoidance/avoidance_node.py
cd ..
colcon build --symlink-install
cd
clear
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
cd ros2_ws/src/
nano robot_avoidance/robot_avoidance/avoidance_node.py
cd ..
colcon build 
cd
clear
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
tmux
nano robot_avoidance/robot_avoidance/avoidance_node.py 
cd ros2_ws/
cd src/
robot_avoidance/robot_avoidance/avoidance_node.py
nano robot_avoidance/robot_avoidance/avoidance_node.py
nano robot_motor/robot_motor/motor_node.py
cd ~/ros2_ws
rm -rf build install log
colcon build --symlink-install
source install/setup.bash
cd
tmux
sudo poweroff
clear
ros2 run robot_motor motor_node
ros2 run robot_avoidance avoidance_node --ros-args -p speed_mode:=slow
ros2 run robot_avoidance avoidance_node
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
clear
ros2 launch sllidar_ros2 sllidar_a1_launch.py 
tmux
sudo poweroff
clear
ip a
clear
rviz2
ros2 topic list
clear
ros2 topic echo /scan
clear
source /opt/ros/humble/setup.bash
source install/setup.bash
clear
ros2 topic echo /scan
ros2 topic echo /laser
ros2 topic echo
clear
sudo apt install ros-$ROS_DISTRO-rplidar-ros
clear
cd /home/rospi/autonomous_car
colcon build --symlink-install
source install/setup.bash
ros2 launch autonomous_car_bringup mapping.launch.py   serial_port:=/dev/ttyUSB0   serial_baudrate:=115200   frame_id:=laser   base_frame:=base_link   odom_frame:=odom   scan_topic:=scan   use_rviz:=true
clear
ros2 launch autonomous_car_bringup mapping.launch.py   serial_port:=/dev/ttyUSB0   serial_baudrate:=115200   frame_id:=laser   base_frame:=base_link   odom_frame:=odom   scan_topic:=scan   use_rviz:=true
it clone https://github.com/Slamtec/rplidar_ros.git -b ros2 src/rplidar_ros && colcon build --symlink-install
sudo apt install ros-humble-rplidar-ros
clear
colcon build --symlink-install
source install/setup.bash
ros2 launch autonomous_car_bringup mapping.launch.py   driver_package:=sllidar_ros2   driver_executable:=sllidar_node   serial_port:=/dev/ttyUSB0   serial_baudrate:=115200   frame_id:=laser   base_frame:=base_link   odom_frame:=odom   scan_topic:=scan   use_rviz:=true
clear
cd ~/autonomous_car
source /opt/ros/humble/setup.bash
source install/setup.bash
export ROS_DOMAIN_ID=23
export ROS_LOCALHOST_ONLY=0   # allow DDS over the LAN
ros2 launch autonomous_car_bringup rplidar_slam.launch.py serial_port:=/dev/ttyUSB0
# in another shell: ros2 topic echo /scan   # should stream ranges
clear
cd ~/autonomous_car
source /opt/ros/humble/setup.bash
colcon build --symlink-install
clear
export ROS_DOMAIN_ID=23
export ROS_LOCALHOST_ONLY=0
clear
cd ~/autonomous_car
source /opt/ros/humble/setup.bash
source install/setup.bash
clear
ls -l /dev/ttyUSB*
clear
ros2 launch autonomous_car_bringup rplidar_slam.launch.py   serial_port:=/dev/ttyUSB0 serial_baudrate:=115200 frame_id:=laser
clear
source /opt/ros/humble/setup.bash && source ~/autonomous_car/install/setup.bash && ros2 run rplidar_ros rplidar_node --ros-args -p serial_port:=/dev/ttyUSB0 -p serial_baudrate:=115200 --log-level info
clear
stty -F /dev/ttyUSB0 115200 raw -echo
timeout 2 cat /dev/ttyUSB0 | hexdump -C
ros2 run rplidar_ros rplidar_node --ros-args -p serial_port:=/dev/ttyUSB0 -p serial_baudrate:=115200
clear
source /opt/ros/humble/setup.bash
source ~/autonomous_car/install/setup.bash
export ROS_DOMAIN_ID=23
export ROS_LOCALHOST_ONLY=0
ros2 launch autonomous_car_bringup rplidar_slam.launch.py   serial_port:=/dev/serial/by-id/usb-Silicon_Labs_CP2102_USB_to_UART_Bridge_Controller_0001-if00-port0   serial_baudrate:=115200 frame_id:=laser
clear
source /opt/ros/humble/setup.bash
source ~/autonomous_car/install/setup.bash
export ROS_DOMAIN_ID=23
export ROS_LOCALHOST_ONLY=0
ros2 topic echo /scan --once
